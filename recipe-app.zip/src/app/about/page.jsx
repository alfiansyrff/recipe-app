import React from 'react'

const AboutPage = () => {
  return (
    <>
      <button className="btn btn-primary">Hello daisyUI!</button>
    </>
  )
}

export default AboutPage